<?php
require_once("phpfuncs/output_html_fns.php");
require_once("phpfuncs/db_fns.php");

?>